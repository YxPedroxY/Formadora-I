import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contato',
  templateUrl: './contato.page.html',
  styleUrls: ['./contato.page.scss'],
  standalone: false,
})
export class ContatoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
