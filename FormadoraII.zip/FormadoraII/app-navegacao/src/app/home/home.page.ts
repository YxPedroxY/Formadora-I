import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
  standalone: false,
})
export class HomePage {
  cep: string = '';
  endereco: any = null;

  constructor(private http: HttpClient) {}

  buscarEndereco() {
    if (!this.cep) return;
    this.http.get(`https://viacep.com.br/ws/${this.cep}/json/`)
      .subscribe((res: any) => {
        this.endereco = res;
      });
  }
}