import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NordestePage } from './nordeste.page';

describe('NordestePage', () => {
  let component: NordestePage;
  let fixture: ComponentFixture<NordestePage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(NordestePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
