import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-nordeste',
  templateUrl: './nordeste.page.html',
  styleUrls: ['./nordeste.page.scss'],
  standalone: false,
})
export class NordestePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
