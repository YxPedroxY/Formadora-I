import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SulPage } from './sul.page';

describe('SulPage', () => {
  let component: SulPage;
  let fixture: ComponentFixture<SulPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(SulPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
