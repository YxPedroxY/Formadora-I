import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sul',
  templateUrl: './sul.page.html',
  styleUrls: ['./sul.page.scss'],
  standalone: false,
})
export class SulPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
