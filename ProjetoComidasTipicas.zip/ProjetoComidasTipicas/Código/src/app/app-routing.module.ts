import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  {
    path: 'home',
    loadChildren: () => import('./home/home.module').then( m => m.HomePageModule)
  },
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  },
  {
    path: 'norte',
    loadChildren: () => import('./norte/norte.module').then( m => m.NortePageModule)
  },
  {
    path: 'nordeste',
    loadChildren: () => import('./nordeste/nordeste.module').then( m => m.NordestePageModule)
  },
  {
    path: 'centro-oeste',
    loadChildren: () => import('./centro-oeste/centro-oeste.module').then( m => m.CentroOestePageModule)
  },
  {
    path: 'sudeste',
    loadChildren: () => import('./sudeste/sudeste.module').then( m => m.SudestePageModule)
  },
  {
    path: 'sul',
    loadChildren: () => import('./sul/sul.module').then( m => m.SulPageModule)
  },
  {
    path: 'login',
    loadChildren: () => import('./login/login.module').then( m => m.LoginPageModule)
  },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
