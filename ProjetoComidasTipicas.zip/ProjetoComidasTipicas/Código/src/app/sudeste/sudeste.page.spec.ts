import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SudestePage } from './sudeste.page';

describe('SudestePage', () => {
  let component: SudestePage;
  let fixture: ComponentFixture<SudestePage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(SudestePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
