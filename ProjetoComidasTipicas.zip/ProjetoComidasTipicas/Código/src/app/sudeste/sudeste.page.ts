import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sudeste',
  templateUrl: './sudeste.page.html',
  styleUrls: ['./sudeste.page.scss'],
  standalone: false,
})
export class SudestePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
