import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { SudestePage } from './sudeste.page';

const routes: Routes = [
  {
    path: '',
    component: SudestePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class SudestePageRoutingModule {}
