import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NortePage } from './norte.page';

describe('NortePage', () => {
  let component: NortePage;
  let fixture: ComponentFixture<NortePage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(NortePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
