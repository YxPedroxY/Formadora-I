import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-norte',
  templateUrl: './norte.page.html',
  styleUrls: ['./norte.page.scss'],
  standalone: false,
})
export class NortePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
