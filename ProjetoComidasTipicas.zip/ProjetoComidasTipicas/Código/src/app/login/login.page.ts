
import { Component, OnInit } from '@angular/core';
import { CepService } from '../services/cep.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
  standalone: false,
})
export class LoginPage implements OnInit {

  cep = '';
  endereco: any = {};
  erro = false;

  constructor(private cepService: CepService) {}

  ngOnInit() {
  }

  buscarCep() {
    this.erro = false;

    if (this.cep.length === 8) {
      this.cepService.buscar(this.cep).subscribe(
        data => {
          if (data.erro) {
            this.endereco = {};
            this.erro = true;
          } else {
            this.endereco = data;
          }
        },
        error => {
          console.error('Erro ao buscar CEP:', error);
          this.erro = true;
        }
      );
    } else {
      this.erro = true;
    }
  }
}
