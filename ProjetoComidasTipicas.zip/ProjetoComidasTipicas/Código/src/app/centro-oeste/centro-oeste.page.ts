import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-centro-oeste',
  templateUrl: './centro-oeste.page.html',
  styleUrls: ['./centro-oeste.page.scss'],
  standalone: false,
})
export class CentroOestePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
