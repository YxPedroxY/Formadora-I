import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CentroOestePage } from './centro-oeste.page';

const routes: Routes = [
  {
    path: '',
    component: CentroOestePage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CentroOestePageRoutingModule {}
