import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CentroOestePage } from './centro-oeste.page';

describe('CentroOestePage', () => {
  let component: CentroOestePage;
  let fixture: ComponentFixture<CentroOestePage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(CentroOestePage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
